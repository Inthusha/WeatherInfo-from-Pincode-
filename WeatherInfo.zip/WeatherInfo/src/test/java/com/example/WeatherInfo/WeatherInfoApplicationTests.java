package com.example.WeatherInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
