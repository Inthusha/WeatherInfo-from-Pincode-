package com.example.WeatherInfo.Tests;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.time.LocalDate;

import com.example.WeatherInfo.Controller.WeatherController;
import com.example.WeatherInfo.DTO.WeatherRequest;
import com.example.WeatherInfo.DTO.WeatherResponse;
import com.example.WeatherInfo.Exception.ApiDownException;
import com.example.WeatherInfo.Exception.InvalidInputException;
import com.example.WeatherInfo.Service.WeatherService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(WeatherController.class)
public class WeatherControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private WeatherService weatherService;

    @Autowired
    private ObjectMapper objectMapper;

    // -------- VALID REQUEST --------
    @Test
    void testGetWeather_validRequest_returnsOk() throws Exception {
        WeatherRequest request = new WeatherRequest();
        request.setPincode("110001");
        request.setForDate(LocalDate.now());

        WeatherResponse response = new WeatherResponse();
        response.setPincode("110001");

        when(weatherService.getWeather(any())).thenReturn(response);

        mockMvc.perform(post("/api/weather")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pincode").value("110001"));
    }

    // -------- INVALID PINCODE --------
    @Test
    void testGetWeather_invalidPincode_returnsBadRequest() throws Exception {
        WeatherRequest request = new WeatherRequest();
        request.setPincode("123"); 
        request.setForDate(LocalDate.now());

        when(weatherService.getWeather(any()))
            .thenThrow(new InvalidInputException("Pincode must be a 6-digit number"));

        mockMvc.perform(post("/api/weather")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    // -------- API DOWN --------
    @Test
    void testGetWeather_apiDown_returnsServiceUnavailable() throws Exception {
        WeatherRequest request = new WeatherRequest();
        request.setPincode("110001");
        request.setForDate(LocalDate.now());

        when(weatherService.getWeather(any()))
            .thenThrow(new ApiDownException("API down"));

        mockMvc.perform(post("/api/weather")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isServiceUnavailable());
    }

    // -------- NULL / EMPTY BODY --------
    @Test
    void testGetWeather_nullBody_returnsBadRequest() throws Exception {
        mockMvc.perform(post("/api/weather")
                .contentType(MediaType.APPLICATION_JSON)
                .content(""))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testGetWeather_emptyJson_returnsBadRequest() throws Exception {
        mockMvc.perform(post("/api/weather")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{}"))
                .andExpect(status().isBadRequest());
    }

    
}
