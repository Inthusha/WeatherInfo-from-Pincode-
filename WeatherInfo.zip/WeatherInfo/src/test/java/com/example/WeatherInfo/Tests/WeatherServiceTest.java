package com.example.WeatherInfo.Tests;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Optional;

import com.example.WeatherInfo.DTO.WeatherRequest;
import com.example.WeatherInfo.DTO.WeatherResponse;
import com.example.WeatherInfo.Entity.Pincode;
import com.example.WeatherInfo.Entity.Weather;
import com.example.WeatherInfo.Exception.ApiDownException;
import com.example.WeatherInfo.Exception.InvalidInputException;
import com.example.WeatherInfo.Repository.PincodeRepository;
import com.example.WeatherInfo.Repository.WeatherRepository;
import com.example.WeatherInfo.Service.WeatherService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class WeatherServiceTest {

    @InjectMocks
    private WeatherService weatherService;

    @Mock
    private WeatherRepository weatherRepo;

    @Mock
    private PincodeRepository pincodeRepo;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    // ---------------- DB has data ----------------
    @Test
    void testGetWeather_valid_returnsResponse() throws Exception {
        WeatherRequest req = new WeatherRequest("110001", LocalDate.now());
        Pincode pincode = new Pincode();
        pincode.setPincode("110001");

        Weather weather = new Weather();
        weather.setPincode(pincode);
        weather.setDate(LocalDate.now());

        when(pincodeRepo.findByPincode("110001")).thenReturn(Optional.of(pincode));
        when(weatherRepo.findByPincodeAndDate(pincode, LocalDate.now())).thenReturn(Optional.of(weather));

        WeatherResponse resp = weatherService.getWeather(req);
        assertEquals("110001", resp.getPincode());
    }

    // ---------------- DB missing → API fetch ----------------
    @Test
    void testGetWeather_pincodeMissing_fetchApiMocked() throws Exception {
        WeatherService spyService = spy(weatherService);

        WeatherRequest req = new WeatherRequest("110001", LocalDate.now());

        Pincode pincode = new Pincode();
        pincode.setPincode("110001");

        Weather weather = new Weather();
        weather.setPincode(pincode);
        weather.setDate(LocalDate.now());

        when(pincodeRepo.findByPincode("110001")).thenReturn(Optional.empty());

        doReturn(pincode).when(spyService).fetchPincodeFromGeoCodeApi("110001");
        doReturn(weather).when(spyService).fetchWeatherFromCurrentWeatherApi(pincode, LocalDate.now());

        when(pincodeRepo.save(pincode)).thenReturn(pincode);
        when(weatherRepo.save(weather)).thenReturn(weather);

        WeatherResponse resp = spyService.getWeather(req);
        assertEquals("110001", resp.getPincode());
    }

    // ---------------- Invalid pincode ----------------
    @Test
    void testGetWeather_invalidPincode_throwsException() {
        WeatherRequest req = new WeatherRequest("123", LocalDate.now());
        assertThrows(InvalidInputException.class, () -> weatherService.getWeather(req));
    }

    // ---------------- Null / blank pincode ----------------
    @Test
    void testGetWeather_nullPincode_throwsException() {
        WeatherRequest req = new WeatherRequest(null, LocalDate.now());
        assertThrows(InvalidInputException.class, () -> weatherService.getWeather(req));
    }

    @Test
    void testGetWeather_blankPincode_throwsException() {
        WeatherRequest req = new WeatherRequest("   ", LocalDate.now());
        assertThrows(InvalidInputException.class, () -> weatherService.getWeather(req));
    }

    // ---------------- Past / Future date ----------------
    @Test
    void testGetWeather_futureDate_throwsException() {
        WeatherRequest req = new WeatherRequest("110001", LocalDate.now().plusDays(1));
        assertThrows(InvalidInputException.class, () -> weatherService.getWeather(req));
    }

    @Test
    void testGetWeather_pastDate_throwsException() {
        WeatherRequest req = new WeatherRequest("110001", LocalDate.now().minusDays(1));
        assertThrows(InvalidInputException.class, () -> weatherService.getWeather(req));
    }

    // ---------------- API down ----------------
    @Test
    void testGetWeather_apiDown_throwsApiDownException() throws Exception {
        WeatherService spyService = spy(weatherService);

        WeatherRequest req = new WeatherRequest("110001", LocalDate.now());

        when(pincodeRepo.findByPincode("110001")).thenReturn(Optional.empty());
        doThrow(new ApiDownException("API down")).when(spyService).fetchPincodeFromGeoCodeApi("110001");

        assertThrows(ApiDownException.class, () -> spyService.getWeather(req));
    }
}
