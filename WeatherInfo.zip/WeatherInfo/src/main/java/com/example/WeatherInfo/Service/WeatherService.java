package com.example.WeatherInfo.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.example.WeatherInfo.DTO.WeatherRequest;
import com.example.WeatherInfo.DTO.WeatherResponse;
import com.example.WeatherInfo.Entity.Pincode;
import com.example.WeatherInfo.Entity.Weather;
import com.example.WeatherInfo.Exception.ApiDownException;
import com.example.WeatherInfo.Exception.InvalidInputException;
import com.example.WeatherInfo.External.GeoZipResponse;
import com.example.WeatherInfo.External.OpenWeatherResponse;
import com.example.WeatherInfo.Repository.PincodeRepository;
import com.example.WeatherInfo.Repository.WeatherRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;



@Service
public class WeatherService 
{
	
	
	
	@Autowired
	private WeatherRepository weatherRepo;
	
	@Autowired
	private PincodeRepository pincodeRepo;
	
	@Autowired
	private WebClient webClient;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Value("${openweather.api.key}")
	private String apiKey;
	
	
	private void validateInput(String pincode, LocalDate date) 
	{ 
		if (pincode == null || pincode.isBlank()) {
	        throw new InvalidInputException("Pincode is required");
	    }
		if (!pincode.matches("\\d{6}")) 
		{ 
			throw new InvalidInputException("Pincode must be a 6-digit number"); 
		}
		if (date == null) 
		{ 
			throw new InvalidInputException("Date is required"); 
		} 

	    LocalDate today = LocalDate.now();
		if (!date.equals(today)) { 
	        throw new InvalidInputException("Only today's date is allowed in format yyyy-MM-dd"); 
	    } 
		
	 }
	
	
	
	
	@Transactional
	public WeatherResponse getWeather(WeatherRequest request) throws JsonMappingException, JsonProcessingException
	{
	 
	    validateInput(request.getPincode(), request.getForDate());
		String pincodeStr=request.getPincode() != null ? request.getPincode().trim() : "";
		
		Optional<Pincode>pinDb=pincodeRepo.findByPincode(pincodeStr);
		
		// (1) Both pincode & weather already in DB
		if(pinDb.isPresent())
		{
			Pincode existingPin=pinDb.get();
			
			Optional<Weather>weatherDb=weatherRepo.findByPincodeAndDate(existingPin, request.getForDate());
			
			if(weatherDb.isPresent())
			{
				return mapToResponse(weatherDb.get());
			}
			
			// (2) Pincode exists, weather missing
			Weather newWeather=fetchWeatherFromCurrentWeatherApi(existingPin,request.getForDate());
			Weather saved=weatherRepo.save(newWeather);
			
			return mapToResponse(saved);
		}
		
		// (3) Pincode missing completely
		Pincode newpin=fetchPincodeFromGeoCodeApi(pincodeStr);
		newpin=pincodeRepo.save(newpin);
		
		Weather newWeather=fetchWeatherFromCurrentWeatherApi(newpin,request.getForDate());
		Weather saved=weatherRepo.save(newWeather);
		
		return mapToResponse(saved);
	}
	
	
	
	
	public Pincode fetchPincodeFromGeoCodeApi(String pincode)
	{
		try {
		String uri="http://api.openweathermap.org/geo/1.0/zip?zip={pincode},IN&appid={apiKey}";
		
		
		
		GeoZipResponse geo=webClient.get()
				           .uri(uri,pincode,apiKey)
				           .retrieve()
				           .bodyToMono(GeoZipResponse.class)
				           .block(Duration.ofSeconds(2));
		
		if(geo==null||geo.getLat()==null||geo.getLon()==null)
		{
			throw new IllegalArgumentException("Unable to fetch coordinates for pincode: " + pincode);
		}
		
		Pincode p=new Pincode();
		p.setPincode(pincode);
		p.setLatitude(geo.getLat());
		p.setLongitude(geo.getLon());
		
		return p;
		}
		catch(WebClientResponseException.NotFound nf)
		{
			throw new InvalidInputException("Invalid pincode: " + pincode);
			
		}catch(WebClientResponseException e)
		{
			
			throw new ApiDownException("Weather API error: "+ e.getStatusCode() + " " + e.getResponseBodyAsString());
		}
		catch (WebClientRequestException e) {
		    throw new ApiDownException("Weather API is unreachable. Please try again later.");
		}
	}
	
	
	
	
	
	public Weather fetchWeatherFromCurrentWeatherApi(Pincode pincode,LocalDate forDate) throws JsonMappingException, JsonProcessingException
	{
		try {
		String uri="https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={apiKey}";
		
		
		String rawJson = webClient.get()
			    .uri(uri, pincode.getLatitude(), pincode.getLongitude(), apiKey)
			    .retrieve()
			    .bodyToMono(String.class)
			    .block(Duration.ofSeconds(2));
		
		OpenWeatherResponse response = objectMapper.readValue(rawJson, OpenWeatherResponse.class);
		
		if(response==null)
		{
			
		   throw new ApiDownException("Weather API returned empty response");
			

		}
		
		Weather w=new Weather();
		w.setPincode(pincode);
		w.setDate(forDate);
		
		if(response.getMain()!=null)
		{
			w.setTemperature(response.getMain().getTemp() - 273.15);
			w.setHumidity(response.getMain().getHumidity());
			
		}
		
		if (response.getWeather() != null && !response.getWeather().isEmpty()) {
		    w.setDescription(response.getWeather().get(0).getDescription());
		}
		if (response.getWind() != null) {
		    w.setWindSpeed(response.getWind().getSpeed());
		}
		
		w.setRawJson(rawJson);
		
		return w;
	}
		
		catch (WebClientResponseException e) {
			throw new ApiDownException("Weather API error: "+ e.getStatusCode() + " " + e.getResponseBodyAsString());
	}
	}
	
	
	

	
	
	
	public WeatherResponse mapToResponse(Weather weather)
	{
		WeatherResponse dto=new WeatherResponse();
		dto.setPincode(weather.getPincode().getPincode());
		dto.setDate(weather.getDate());
		dto.setLatitude(weather.getPincode().getLatitude());
		dto.setLongitude(weather.getPincode().getLongitude());
		dto.setTemperature(weather.getTemperature());
		dto.setHumidity(weather.getHumidity());
		dto.setDescription(weather.getDescription());
		dto.setWindSpeed(weather.getWindSpeed());
		return dto;
		
	}
	
	
	
	

}
