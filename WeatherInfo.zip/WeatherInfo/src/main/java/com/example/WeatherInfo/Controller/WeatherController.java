package com.example.WeatherInfo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.WeatherInfo.DTO.WeatherRequest;
import com.example.WeatherInfo.DTO.WeatherResponse;
import com.example.WeatherInfo.Service.WeatherService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/weather")
public class WeatherController 
{
	@Autowired
	private WeatherService weatherService;
	
	@PostMapping
	public ResponseEntity<WeatherResponse> getWeather(@Valid @RequestBody  WeatherRequest request) throws JsonMappingException, JsonProcessingException
	{
		WeatherResponse response=weatherService.getWeather(request);
		return ResponseEntity.ok(response);
	}

}
