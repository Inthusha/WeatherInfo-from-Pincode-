package com.example.WeatherInfo.Entity;

import java.time.LocalDate;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(
	   
	    uniqueConstraints = @UniqueConstraint(columnNames = {"pincode", "date"})
	)
public class Weather 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
    @JoinColumn(name = "pincode_id")
	private Pincode pincode;
	private LocalDate date;
	private Double temperature;
	private Double humidity;
	private String description;
	private Double windSpeed;
	
	@Lob
	@Column(columnDefinition="TEXT")
	private String rawJson;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Pincode getPincode() {
		return pincode;
	}

	public void setPincode(Pincode pincode) {
		this.pincode = pincode;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Double getTemperature() {
		return temperature;
	}

	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
    
	public Double getHumidity() {
		return humidity;
	}

	public void setHumidity(Double humidity) {
		this.humidity = humidity;
	}

	public Double getWindSpeed() {
		return windSpeed;
	}

	public void setWindSpeed(Double windSpeed) {
		this.windSpeed = windSpeed;
	}

	public String getRawJson() {
		return rawJson;
	}

	public void setRawJson(String rawJson) {
		this.rawJson = rawJson;
	}

	

	@Override
	public String toString() {
		return "Weather [id=" + id + ", pincode=" + pincode + ", date=" + date + ", temperature=" + temperature
				+ ", humidity=" + humidity + ", description=" + description + ", windSpeed=" + windSpeed + ", rawJson="
				+ rawJson + "]";
	}

	public Weather(Long id, Pincode pincode, LocalDate date, Double temperature, Double humidity, String description,
			Double windSpeed, String rawJson) {
		super();
		this.id = id;
		this.pincode = pincode;
		this.date = date;
		this.temperature = temperature;
		this.humidity = humidity;
		this.description = description;
		this.windSpeed = windSpeed;
		this.rawJson = rawJson;
	}

	public Weather() {
		super();
	}

	
	

}
