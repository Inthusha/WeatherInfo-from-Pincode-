package com.example.WeatherInfo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.WeatherInfo.Entity.Weather;
import com.example.WeatherInfo.Entity.Pincode;
import java.util.List;
import java.util.Optional;
import java.time.LocalDate;


public interface WeatherRepository extends JpaRepository<Weather,Long> 
{
	
	Optional<Weather> findByPincodeAndDate(Pincode pincode, LocalDate date);

}
