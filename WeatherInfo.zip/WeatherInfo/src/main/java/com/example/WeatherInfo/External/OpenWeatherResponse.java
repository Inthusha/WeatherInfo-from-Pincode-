package com.example.WeatherInfo.External;

import java.util.List;


public class OpenWeatherResponse 
{
	private Coord coord;
    private List<WeatherItem> weather;
    private Main main;
    private Wind wind;
    private Long dt;
    private String name;
	public List<WeatherItem> getWeather() {
		return weather;
	}
	public void setWeather(List<WeatherItem> weather) {
		this.weather = weather;
	}
	public Main getMain() {
		return main;
	}
	public void setMain(Main main) {
		this.main = main;
	}
	public Wind getWind() {
		return wind;
	}
	public void setWind(Wind wind) {
		this.wind = wind;
	}
	public Long getDt() {
		return dt;
	}
	public void setDt(Long dt) {
		this.dt = dt;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Coord getCoord() {
		return coord;
	}
	public void setCoord(Coord coord) {
		this.coord = coord;
	}
	
	public OpenWeatherResponse(Coord coord, List<WeatherItem> weather, Main main, Wind wind, Long dt, String name) {
		super();
		this.coord = coord;
		this.weather = weather;
		this.main = main;
		this.wind = wind;
		this.dt = dt;
		this.name = name;
	}
	public OpenWeatherResponse() {
		super();
	}
    



public static class WeatherItem{
	private String main;
	private String description;
	public String getMain() {
		return main;
	}
	public void setMain(String main) {
		this.main = main;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public WeatherItem(String main, String description) {
		super();
		this.main = main;
		this.description = description;
	}
	public WeatherItem() {
		super();
	}
}


public static class Main {
    private Double temp;     
    private Double pressure; 
    private Double humidity;
	public Double getTemp() {
		return temp;
	}
	public void setTemp(Double temp) {
		this.temp = temp;
	}
	public Double getPressure() {
		return pressure;
	}
	public void setPressure(Double pressure) {
		this.pressure = pressure;
	}
	public Double getHumidity() {
		return humidity;
	}
	public void setHumidity(Double humidity) {
		this.humidity = humidity;
	}
	public Main(Double temp, Double pressure, Double humidity) {
		super();
		this.temp = temp;
		this.pressure = pressure;
		this.humidity = humidity;
	}
	public Main() {
		super();
	} 
    
    
}

public static class Wind {
    private Double speed;

	public Double getSpeed() {
		return speed;
	}

	public void setSpeed(Double speed) {
		this.speed = speed;
	}

	public Wind(Double speed) {
		super();
		this.speed = speed;
	}

	public Wind() {
		super();
	} 
    
    
    
}

public static class Coord {
	
    private Double lon;
    private Double lat;
	public Double getLon() {
		return lon;
	}
	public void setLon(Double lon) {
		this.lon = lon;
	}
	public Double getLat() {
		return lat;
	}
	public void setLat(Double lat) {
		this.lat = lat;
	}
	public Coord(Double lon, Double lat) {
		super();
		this.lon = lon;
		this.lat = lat;
	}
	public Coord() {
		super();
	}
    
    
 
}

}





