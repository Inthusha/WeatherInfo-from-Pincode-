package com.example.WeatherInfo.Exception;


public class ApiDownException extends RuntimeException 
{
   public ApiDownException(String message) { super(message); }
}

	
