package com.example.WeatherInfo.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.WeatherInfo.Entity.Pincode;

public interface PincodeRepository extends JpaRepository<Pincode,Long>{
	
	Optional<Pincode>findByPincode(String pincode);
	

}
