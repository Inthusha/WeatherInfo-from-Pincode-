package com.example.WeatherInfo.DTO;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;


public class WeatherRequest 
{
	 @NotBlank(message = "Pincode is required")
	 @Pattern(regexp = "\\d{6}", message = "Pincode must be 6 digits")
	 private String pincode;
	 
	 @NotNull(message = "Date is required")
	 @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	 private LocalDate forDate;
	
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public LocalDate getForDate() {
		return forDate;
	}
	public void setForDate(LocalDate forDate) {
		this.forDate = forDate;
	}
	@Override
	public String toString() {
		return "WeatherRequest [pincode=" + pincode + ", forDate=" + forDate + "]";
	}
	public WeatherRequest(String pincode, LocalDate forDate) {
		super();
		this.pincode = pincode;
		this.forDate = forDate;
	}
	public WeatherRequest() {
		super();
	}
	
	

}
